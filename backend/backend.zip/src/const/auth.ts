export const TOKEN_NAME = 'token';
