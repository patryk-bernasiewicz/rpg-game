describe('User entity', () => {
  beforeAll(async () => {});

  it('should create a new user', async () => {});

  it('encrypts user password', async () => {});
});
